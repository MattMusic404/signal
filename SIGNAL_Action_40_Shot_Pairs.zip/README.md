# SIGNAL MiniMax H3 action prompts

Upload the PNG named for the shot and paste its matching TXT into image-to-video. The durations are editorial targets. Choose the closest available setting and trim in the edit. Each prompt starts from the supplied image and describes one continuous take. Review character continuity and motion before queueing the whole sequence.

